import os
from flask import Flask, render_template, jsonify, send_from_directory

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_users/<letter>')
def get_users(letter):
    # Fetch users starting with the given letter from your storage (file or DB)
    users = get_users_from_storage(letter)
    return jsonify(users)

def get_users_from_storage(letter):
    file_path = os.path.join(os.path.dirname(__file__), 'data', 'users.txt')

    with open(file_path, 'r') as file:
        users = [line.strip() for line in file if line.startswith(letter)]

    return users

# Serve static files (CSS and JavaScript) from the 'static' directory
@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory(os.path.join(os.path.dirname(__file__), 'static'), filename)

if __name__ == '__main__':
    app.run(debug=True)
