document.addEventListener('DOMContentLoaded', function() {
    // Assume there is an HTML element with the id 'userList' to display the users
    const userListElement = document.getElementById('userList');

    // Fetch and display user data for the letter 'A'
    fetchUsers('A').then(data => {
        // Add logic to render the user list (e.g., update HTML elements)
        userListElement.innerHTML = generateUserListHTML(data);
    });
});

function fetchUsers(letter) {
    return fetch('/get_users/' + letter)
        .then(response => response.json())
        .catch(error => console.error('Error fetching users:', error));
}
function generateUserListHTML(users) {
    // Check if there are no users
    if (users.length === 0) {
        return '<p>No users found for the selected letter.</p>';
    }

    // Generate HTML for displaying the user list
    const userListHTML = '<ul>' + users.map(user => `<li>${user}</li>`).join('') + '</ul>';

    return userListHTML;
}